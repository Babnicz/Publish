"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# DemoEncode module - Zadani hesla a textu k zakodovani -> Vystup souradnic / zakodovaneho payloadu

import json
from Config import config
from HexSplit import HexSplit
from HexToDec import HexToDec
from SearchInRn import SearchInt
from TextToIra import TextToIra


def text_to_hex(text: str) -> str:
    """Converts a UTF-8 string into an uppercase hexadecimal string."""
    return text.encode("utf-8").hex().upper()


def encode_text(
    text: str,
    password: str,
    chunk_size: int | None = None,
    max_search_digits: int | None = None,
    sequential_search: bool | None = None,
) -> dict:
    """
    Encodes text using a password-derived irrational number.
    Returns a dictionary containing metadata, original byte length, chunk size,
    and coordinate blocks needed for decoding.
    """
    effective_chunk_size = (
        chunk_size if chunk_size is not None else getattr(config.search, "hex_chunk_size", 4)
    )
    effective_max_search = (
        max_search_digits
        if max_search_digits is not None
        else getattr(config.search, "max_search_digits", 10_000_000)
    )
    effective_sequential = (
        sequential_search
        if sequential_search is not None
        else getattr(config.search, "sequential_search", True)
    )

    converter = TextToIra(password)
    a, b = converter.get_numbers()

    hex_data = text_to_hex(text)
    chunks = HexSplit(hex_data, chunk_size=effective_chunk_size)
    total_chunks = len(chunks)

    print(f"\n[Info] Input text: '{text}'")
    print(f"[Info] Hex representation: {hex_data} ({len(hex_data)} characters)")
    print(
        f"[Info] Split into {total_chunks} block(s) of {effective_chunk_size} hex chars "
        f"({effective_chunk_size * 4} bits each)."
    )
    print(f"[Info] Starting search in sqrt({a} / {b})...\n")

    encoded_blocks = []
    current_search_position = 1

    for idx, chunk in enumerate(chunks, start=1):
        dec_val = HexToDec(chunk, expected_length=effective_chunk_size)
        target_str = str(dec_val)
        search_start = current_search_position if effective_sequential else 1

        print(f"   [Block {idx}/{total_chunks}] Hex '{chunk}' -> Dec: {dec_val}")
        print(f"      -> Searching from position {search_start}...")

        position = SearchInt(
            a,
            b,
            target_str,
            max_search_digits=effective_max_search,
            start_position=search_start,
        )

        target_length = len(target_str)
        print(f"      -> OK: Found at position {position} (length {target_length})")

        encoded_blocks.append({
            "position": position,
            "length": target_length,
        })

        if effective_sequential:
            current_search_position = position + target_length

    # Full payload package for decoding
    payload = {
        "version": 1,
        "chunk_length": effective_chunk_size,
        "byte_length": len(text.encode("utf-8")),
        "blocks": encoded_blocks,
    }

    return payload


def run():
    min_len = config.text_to_ira.min_text_length
    chunk_size = config.search.hex_chunk_size

    print("==================================================")
    print(" DEMO 1: ENCODE TEXT TO IRRATIONAL COORDINATES")
    print("==================================================")
    print(f"Active configuration:")
    print(f" - Min password length : {min_len} characters")
    print(f" - Hex chunk size      : {chunk_size} characters ({chunk_size * 4} bits)")
    print("Type 'exit' anytime to quit.\n")

    while True:
        try:
            # 1. Heslo
            password = input(f"Enter password for irrational number (min. {min_len} chars): ").strip()
            if password.lower() == "exit":
                break
            if not password:
                continue

            try:
                # Validace hesla
                TextToIra(password)
            except ValueError as e:
                print(f"[Validation Error]: {e}\n")
                continue

            # 2. Text k zakodovani
            text_to_encode = input("Enter text to encode: ").strip()
            if text_to_encode.lower() == "exit":
                break
            if not text_to_encode:
                print("Text cannot be empty.\n")
                continue

            # 3. Kodovani
            payload = encode_text(text_to_encode, password)

            print("\n" + "=" * 50)
            print(" ENCODING SUCCESSFUL! COPY THE PAYLOAD BELOW:")
            print("=" * 50)
            payload_json = json.dumps(payload)
            print(payload_json)
            print("=" * 50)
            print("Use DemoDecode.py with this payload and your password to decode.\n")

        except ValueError as err:
            print(f"\n[Error]: {err}\n")
        except (KeyboardInterrupt, EOFError):
            print("\nTerminated.")
            break


if __name__ == "__main__":
    run()
