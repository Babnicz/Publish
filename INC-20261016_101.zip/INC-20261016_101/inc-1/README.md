# INC (Irrational Number Codec)

A Python library and demonstration toolset for encoding and decoding arbitrary data into coordinates within the decimal expansion of irrational numbers in the form $\sqrt{a / b}$.

Author's vision and original idea:
The original vision comes from the idea to find the correct irrational number from infinite variants representing the elements without the need to refer to position or split the element.

“We don’t store data; we discover its coordinates. The secret is never the message, but the key to the universe where it already lives.”

---

## Operating Principle

The codec maps input text to coordinates (starting position and length) inside the fractional expansion of an irrational number:
1. **Password $\to$ Irrational Number:** A passphrase is systematically converted into a pair of large integers $(a, b)$ that define an irrational square root $\sqrt{a / b}$.
2. **Text $\to$ Hex $\to$ Dec:** The input text is encoded as a UTF-8 hexadecimal string, divided into fixed-size chunks, and each chunk is converted into a decimal integer.
3. **Encoding (Coordinate Discovery):** Digits of the fractional expansion of $\sqrt{a / b}$ are generated in a streaming window to locate the decimal representation of each chunk. The result is a set of coordinate blocks `(position, length)`.
4. **Decoding (Direct Reconstruction):** Using the identical passphrase, the digits at each `(position, length)` are computed directly using high-precision arithmetic, converted back to hex chunks, combined, and decoded back into the original text.

---

## Core Functions and Modules

### 1. `TextToIra` (`TextToIra.py`)
- **Class:** `TextToIra(text: str, min_length: int | None = None)`
- **Helper Function:** `text_to_ira(text: str, min_length: int | None = None) -> tuple[int, int]`
- **Description:** Converts an input passphrase into two positive integers `(a, b)` such that $\sqrt{a / b}$ is guaranteed to be an irrational number.
- **How it works:**
  - Validates that the input length satisfies `min_text_length` (default: 20 characters).
  - Splits the text into two segments (the full text and the last word/characters).
  - Converts UTF-8 byte representations into big-endian decimal integers.
  - Checks if $a \cdot b$ forms a perfect square (which would yield a rational square root). If so, it increments $a$ until an irrational ratio is guaranteed.
- **Key Method:** `converter.get_numbers() -> tuple[int, int]` returns the `(a, b)` pair.

### 2. `HexSplit` (`HexSplit.py`)
- **Function:** `HexSplit(hex_str: str, chunk_size: int = 8) -> list[str]`
- **Description:** Splits an uppercase hexadecimal string into fixed-length segments of `chunk_size` characters (e.g., 4 hex characters = 16 bits). If the final chunk is shorter than `chunk_size`, it is left-padded with zeros (`zfill`).

### 3. `HexToDec` (`HexToDec.py`)
- **Function:** `HexToDec(hex_str: str, expected_length: int = 4) -> int`
- **Description:** Converts a hexadecimal chunk into a decimal integer. Validates hexadecimal character validity and verifies expected chunk length.

### 4. `SearchInt` (`SearchInRn.py`)
- **Function:** `SearchInt(a: int, b: int, target: int | str, max_search_digits: int = 1_000_000, start_position: int = 1) -> int`
- **Description:** Searches for a decimal target digit sequence within the fractional expansion of $\sqrt{a / b}$.
- **Streaming Implementation:** Uses `_stream_irrational_digits` and `collections.deque(maxlen=len(target))` to slide through expansion digits one-by-one without retaining millions of digits in memory.
- **Parameters:**
  - `start_position`: 1-based index behind the decimal point where the search starts (enables sequential non-overlapping searches).
  - `max_search_digits`: Maximum number of digits to inspect before raising `ValueError`.
- **Return Value:** 1-based index pointing to where the sequence begins after the decimal point.

### 5. `ReturnInt` (`SearchInRn.py`)
- **Function:** `ReturnInt(a: int, b: int, position: int, length: int) -> int`
- **Description:** Directly calculates and extracts `length` digits starting at `position` (1-based index) behind the decimal point of $\sqrt{a / b}$ using arbitrary-precision arithmetic (`decimal.Decimal`). Avoids sequential scanning.

### 6. `DecToHex` (`DecToHex.py`)
- **Function:** `DecToHex(num: int, length: int = 4) -> str`
- **Description:** Converts a decimal integer back into an uppercase hexadecimal string padded with leading zeros to `length` characters.

### 7. `HexJoin` (`HexJoin.py`)
- **Function:** `HexJoin(chunks: list[str]) -> str`
- **Description:** Validates and concatenates a list of hexadecimal chunks into a single uppercase hexadecimal string.

### 8. High-Level Pipelines (`Code.py` & `Decode.py`)
- **`CodeHex(hex_str, a, b, ...)` (`Code.py`):** Encapsulates `HexSplit` $\to$ `HexToDec` $\to$ `SearchInt` to encode a hex string into a list of coordinate dictionaries `{"chunk_hex", "decimal_value", "position", "length"}`.
- **`DecodeHex(encoded_blocks, a, b, ...)` (`Decode.py`):** Encapsulates `ReturnInt` $\to$ `DecToHex` $\to$ `HexJoin` to reconstruct the hex string from coordinate blocks.

---

## How Functions are Used in Demo Scripts

The repository includes three demonstration scripts covering the end-to-end workflow and detached payload transfer.

### 1. `Demo.py` (Interactive End-to-End Walkthrough)
A single interactive terminal session showing the entire encoding and decoding pipeline:
- **Step 1 (Passphrase & Key Derivation):**
  - Prompts user for a passphrase (min. 20 characters).
  - Calls `TextToIra(ira_password).get_numbers()` to produce `a` and `b`.
- **Step 2 (Encoding):**
  - User inputs plaintext $\to$ converted to hex (`text_to_hex`).
  - `HexSplit(hex_data, chunk_size)` divides hex string into chunks (default 4 hex chars = 16 bits).
  - `encode_text_sequential()` iterates over chunks:
    - Calls `HexToDec(chunk)` to get target integer.
    - Calls `SearchInt(a, b, target_str, start_position=search_start)` to locate its position in $\sqrt{a / b}$.
    - Advances `current_search_position = position + length` (`sequential_search = True`), guaranteeing unique sequential locations.
- **Step 3 (Decoding):**
  - Prompts for decoding passphrase (verifying mismatch detection if a wrong password is used).
  - Calls `TextToIra(decode_password).get_numbers()` to compute decoding `dec_a` and `dec_b`.
  - For each coordinate block:
    - Calls `ReturnInt(dec_a, dec_b, position, length)` to retrieve the decimal value directly.
    - Calls `DecToHex(retrieved_dec, length=chunk_size)` to restore the chunk.
  - Calls `HexJoin(decoded_chunks)` to reassemble the complete hex string.
- **Step 4 (Verification):**
  - Trims hex padding using original byte length, converts back to UTF-8 (`hex_to_text`), and validates that reconstructed text matches original input.

### 2. `DemoEncode.py` (Sender: Text $\to$ Encoded Payload)
Standalone script for generating a shareable encoded payload:
- Reads passphrase and plaintext.
- Invokes `TextToIra` to get `(a, b)`.
- Uses `HexSplit`, `HexToDec`, and `SearchInt` to generate coordinate blocks.
- Outputs a serialized JSON payload containing:
  ```json
  {
    "version": 1,
    "chunk_length": 4,
    "byte_length": 13,
    "blocks": [
      {"position": 1420, "length": 5},
      {"position": 89231, "length": 4}
    ]
  }
  ```

### 3. `DemoDecode.py` (Receiver: Payload $\to$ Decoded Text)
Standalone script for recovering plaintext from an encoded payload:
- Prompts for the passphrase and the JSON payload string.
- Derives `(a, b)` from the passphrase via `TextToIra`.
- Iterates over `blocks` from the payload, calling `ReturnInt` and `DecToHex` for each coordinate.
- Joins the hex chunks with `HexJoin`, trims to `byte_length`, and prints the original plaintext.

---

## Configuration (`inc_config.ini` / `Config.py`)

Settings can be customized via `inc_config.ini` or programmatically via `Config.py`:
- `hex_chunk_size` (default: `4`): Number of hex characters per chunk (4 characters = 16 bits, values 0–65,535).
- `max_search_digits` (default: `10000000`): Search limit for digits in the fractional expansion.
- `sequential_search` (default: `true`): When true, subsequent chunk searches start at the index where the previous chunk was found.
- `min_text_length` (default: `20`): Minimum password character length for `TextToIra`.

---

## Dependencies

### Prerequisites & Python Version
- **Python 3.10+** (Python 3.10 or newer is required due to modern type hint syntax, including union types `int | str` and built-in generic types like `tuple[str, str]` and `list[dict]`).

### External Packages
- **None** — This project is designed with zero third-party dependencies and relies entirely on Python's built-in standard library. No additional packages need to be installed via `pip` to run the library or demo scripts.

### Standard Library Modules Used
The codebase utilizes the following standard library modules (bundled automatically with Python):
- **`decimal`** — Arbitrary-precision decimal arithmetic for irrational number expansions and square root approximations.
- **`math`** — High-performance integer square root calculation (`math.isqrt`) and mathematical utilities.
- **`collections`** — Specifically `collections.deque` with a fixed maximum length (`maxlen`) for streaming sliding-window searches.
- **`configparser`**, **`dataclasses`**, **`json`**, **`pathlib`** — Application configuration and payload serialization.

### Build System Dependencies (Optional)
If building or packaging the project using `pyproject.toml`:
- **`setuptools`** — Configured as the build backend in `pyproject.toml`.


