"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# SearchInRn library module

import decimal
from collections import deque


def _stream_irrational_digits(a: int, b: int, start_position: int = 1, chunk_size: int = 2000):
    """
    Generator that yields digits of sqrt(a/b) behind the decimal point continuously
    starting from start_position (1-based) using streaming generation without storing all digits in RAM.
    """
    if not isinstance(a, int) or isinstance(a, bool):
        raise TypeError(f"Input 'a' must be an integer, got {type(a).__name__} instead.")
    if not isinstance(b, int) or isinstance(b, bool):
        raise TypeError(f"Input 'b' must be an integer, got {type(b).__name__} instead.")
    if not isinstance(start_position, int) or isinstance(start_position, bool):
        raise TypeError(f"start_position must be an integer, got {type(start_position).__name__} instead.")
    if start_position < 1:
        raise ValueError(f"start_position must be >= 1, got {start_position}")

    if b == 0:
        raise ValueError("Combination does not produce a real number: division by zero (b = 0).")
    if (a > 0 and b < 0) or (a < 0 and b > 0):
        raise ValueError(
            f"Combination of a={a} and b={b} does not produce a real number (square root of negative ratio)."
        )

    int_part_digits = len(str(int(a // b))) if (b != 0 and a >= b) else 0
    curr_prec = int_part_digits + start_position + chunk_size + 50
    yielded_count = start_position - 1

    while True:
        with decimal.localcontext() as ctx:
            ctx.prec = curr_prec
            a_dec = decimal.Decimal(a)
            b_dec = decimal.Decimal(b)
            ratio = a_dec / b_dec
            val = ratio.sqrt()

            val_str = str(val)
            if "." not in val_str:
                raise ValueError(f"Combination of a={a} and b={b} yields a rational number.")

            frac_str = val_str.split(".")[1]

            # Exclude safety buffer digits at the end to prevent rounding inaccuracies
            safe_available = len(frac_str) - 20
            if safe_available <= yielded_count:
                curr_prec += chunk_size
                continue

            new_digits = frac_str[yielded_count:safe_available]
            for d in new_digits:
                yield d
                yielded_count += 1

            curr_prec += chunk_size


def SearchInt(
    a: int,
    b: int,
    target: int | str,
    max_search_digits: int = 1_000_000,
    start_position: int = 1,
) -> int:
    """
    Searches for a target integer/sequence in the fractional expansion of sqrt(a/b)
    using Method 1: Streaming generation and sliding window, starting at start_position.

    :param a: Numerator integer for irrational number sqrt(a/b).
    :param b: Denominator integer for irrational number sqrt(a/b).
    :param target: Integer or digit string to search for.
    :param max_search_digits: Maximum number of digits to inspect before stopping (default 1,000,000).
    :param start_position: 1-based ordinal position where search starts (default 1).
    :return: 1-based ordinal position where the sequence starts after the decimal point.
    :raises ValueError: If target is not found within max_search_digits or inputs are invalid.
    """
    if not isinstance(start_position, int) or isinstance(start_position, bool):
        raise TypeError(f"start_position must be an integer, got {type(start_position).__name__} instead.")
    if start_position < 1:
        raise ValueError(f"start_position must be >= 1, got {start_position}")

    target_str = str(target).strip()
    if not target_str.isdigit():
        raise ValueError(f"Target must contain only digits, got '{target}'")

    win_len = len(target_str)
    window = deque(maxlen=win_len)

    digit_counter = start_position - 1
    inspected_count = 0

    for digit in _stream_irrational_digits(a, b, start_position=start_position):
        digit_counter += 1
        inspected_count += 1
        window.append(digit)

        if len(window) == win_len:
            if "".join(window) == target_str:
                # Return 1-based start index
                return digit_counter - win_len + 1

        if inspected_count >= max_search_digits:
            break

    raise ValueError(
        f"Sequence '{target_str}' not found in {max_search_digits} digits of sqrt({a}/{b}) "
        f"starting from position {start_position}."
    )


def ReturnInt(a: int, b: int, position: int, length: int) -> int:
    """
    Returns the integer starting at a specific ordinal position in sqrt(a/b)
    using Method 2: Direct targeted position calculation.

    :param a: Numerator integer for irrational number sqrt(a/b).
    :param b: Denominator integer for irrational number sqrt(a/b).
    :param position: 1-based starting ordinal position behind decimal point.
    :param length: Number of digits to extract.
    :return: Integer formed by digits at the specified position.
    :raises ValueError: If position or length are invalid.
    """
    if position < 1:
        raise ValueError(f"Position must be >= 1, got {position}")
    if length < 1:
        raise ValueError(f"Length must be >= 1, got {length}")

    int_part_digits = len(str(int(a // b))) if (b != 0 and a >= b) else 0
    required_prec = int_part_digits + position + length + 50

    with decimal.localcontext() as ctx:
        ctx.prec = required_prec
        a_dec = decimal.Decimal(a)
        b_dec = decimal.Decimal(b)

        if b == 0:
            raise ValueError("Division by zero (b = 0).")
        if (a > 0 and b < 0) or (a < 0 and b > 0):
            raise ValueError("Square root of a negative ratio is not real.")

        ratio = a_dec / b_dec
        val = ratio.sqrt()

        val_str = str(val)
        if "." not in val_str:
            raise ValueError(f"Combination a={a}, b={b} yields a rational number.")

        frac_str = val_str.split(".")[1]

        start_idx = position - 1
        end_idx = start_idx + length

        if len(frac_str) < end_idx:
            raise ValueError("Calculated precision was insufficient.")

        extracted_str = frac_str[start_idx:end_idx]
        return int(extracted_str)


# Pythonic aliases
search_int = SearchInt
return_int = ReturnInt

