"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# HexSplit library module


def HexSplit(hex_str: str, chunk_size: int = 8) -> list[str]:
    """
    Splits a hexadecimal string into a list of fixed-size uppercase hexadecimal chunks.
    If the final chunk is shorter than `chunk_size`, it is padded with leading zeros.

    :param hex_str: Hexadecimal input string.
    :param chunk_size: Character length of each chunk (default 8).
    :return: List of uppercase hexadecimal strings, each of length `chunk_size`.
    :raises TypeError: If inputs are not of correct types.
    :raises ValueError: If input string contains non-hexadecimal characters or chunk_size <= 0.
    """
    if not isinstance(hex_str, str):
        raise TypeError(f"Input hex_str must be a string, got {type(hex_str).__name__}")
    if not isinstance(chunk_size, int) or isinstance(chunk_size, bool):
        raise TypeError(f"chunk_size must be an integer, got {type(chunk_size).__name__}")
    if chunk_size <= 0:
        raise ValueError(f"chunk_size must be greater than 0, got {chunk_size}")

    cleaned_str = hex_str.strip()
    if not cleaned_str:
        return []

    # Validate hex characters
    try:
        int(cleaned_str, 16)
    except ValueError as e:
        raise ValueError(f"Input string '{cleaned_str}' contains invalid hexadecimal characters.") from e

    chunks = []
    for i in range(0, len(cleaned_str), chunk_size):
        chunk = cleaned_str[i : i + chunk_size].upper()
        if len(chunk) < chunk_size:
            chunk = chunk.zfill(chunk_size)
        chunks.append(chunk)

    return chunks


# Alias for snake_case python convention
hex_split = HexSplit

