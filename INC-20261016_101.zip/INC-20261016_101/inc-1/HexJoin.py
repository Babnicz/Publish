"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# HexJoin library module


def HexJoin(chunks: list[str]) -> str:
    """
    Joins a list of hexadecimal chunks into a single uppercase hexadecimal string.

    :param chunks: List of hexadecimal strings.
    :return: Combined uppercase hexadecimal string.
    :raises TypeError: If input is not a list or elements are not strings.
    :raises ValueError: If any chunk contains non-hexadecimal characters.
    """
    if not isinstance(chunks, list):
        raise TypeError(f"Input chunks must be a list, got {type(chunks).__name__}")

    for idx, chunk in enumerate(chunks):
        if not isinstance(chunk, str):
            raise TypeError(f"Element at index {idx} must be a string, got {type(chunk).__name__}")
        chunk_clean = chunk.strip()
        if chunk_clean:
            try:
                int(chunk_clean, 16)
            except ValueError as e:
                raise ValueError(f"Chunk at index {idx} ('{chunk}') contains invalid hexadecimal characters.") from e

    return "".join(c.strip().upper() for c in chunks)


# Alias for snake_case python convention
hex_join = HexJoin

