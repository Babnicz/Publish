Do not repeate paterns in the search
