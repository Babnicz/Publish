"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# TextToIra library module

import math
from Config import config


class TextToIra:
    """
    Class for converting a text string into two decimal numbers (a, b)
    that form an irrational number sqrt(a/b) for cryptographic search/indexing.
    """

    MIN_LENGTH = 20

    def __init__(self, text: str, min_length: int | None = None):
        """
        Initializes TextToIra with the given input string.

        :param text: Input text string of at least min_length characters.
        :param min_length: Optional explicit minimum length (defaults to config value if None).
        :raises TypeError: If text is not a string.
        :raises ValueError: If text is shorter than min_length characters.
        """
        if not isinstance(text, str):
            raise TypeError(f"Input value must be a string, got: {type(text).__name__}")

        effective_min_length = (
            min_length
            if min_length is not None
            else getattr(config.text_to_ira, "min_text_length", self.MIN_LENGTH)
        )

        if len(text) < effective_min_length:
            raise ValueError(
                f"Input string must not be shorter than {effective_min_length} characters (provided {len(text)} characters)."
            )

        self._min_length = effective_min_length
        self._text = text
        self._part1, self._part2 = self._split_text(text)
        self._a, self._b = self._compute_decimal_pair(self._part1, self._part2)

    @classmethod
    def _split_text(cls, text: str) -> tuple[str, str]:
        """
        Splits text into two parts:
        - Part 1: Entire input string.
        - Part 2: Last word of the string. If string consists of only one word,
                  the fallback number of characters (from config) are taken.
        """
        part1 = text
        words = text.strip().split()
        fallback_len = getattr(config.text_to_ira, "single_word_fallback_length", 10)

        if len(words) <= 1:
            # Single word string -> take the last fallback_len characters
            part2 = text[-fallback_len:] if len(text) >= fallback_len else text
        else:
            # Last word of the string
            part2 = words[-1]

        return part1, part2

    @classmethod
    def _text_to_decimal(cls, s: str) -> int:
        """
        Converts a text string to a positive decimal integer representation
        using UTF-8 byte encoding.
        """
        bytes_data = s.encode('utf-8')
        return int.from_bytes(bytes_data, byteorder='big')

    @classmethod
    def _ensure_irrational(cls, a: int, b: int) -> tuple[int, int]:
        """
        Adjusts (increases to nearest possible values) decimal numbers a and b
        such that their ratio under square root sqrt(a/b) forms an irrational number.

        sqrt(a/b) is rational if and only if (a * b) is a perfect square.
        If a * b is a perfect square, a is incremented to the nearest value.
        """
        if b <= 0:
            b = 1
        if a <= 0:
            a = 1

        while True:
            prod = a * b
            sq = math.isqrt(prod)
            if sq * sq == prod:
                # a/b produces a rational square root, increase to nearest value
                a += 1
            else:
                break

        return a, b

    @classmethod
    def _compute_decimal_pair(cls, part1: str, part2: str) -> tuple[int, int]:
        """
        Converts two string parts to decimal numbers and ensures their irrationality.
        """
        dec1 = cls._text_to_decimal(part1)
        dec2 = cls._text_to_decimal(part2)
        return cls._ensure_irrational(dec1, dec2)

    @property
    def text(self) -> str:
        """Original input string."""
        return self._text

    @property
    def part1(self) -> str:
        """First string part (entire input)."""
        return self._part1

    @property
    def part2(self) -> str:
        """Second string part (last word or last 10 characters)."""
        return self._part2

    @property
    def a(self) -> int:
        """Numerator decimal number for irrational number calculation."""
        return self._a

    @property
    def b(self) -> int:
        """Denominator decimal number for irrational number calculation."""
        return self._b

    def get_numbers(self) -> tuple[int, int]:
        """
        Returns the pair of decimal numbers (a, b).

        :return: Tuple of two integers (a, b).
        """
        return self._a, self._b


# Functional helper alias
def text_to_ira(text: str, min_length: int | None = None) -> tuple[int, int]:
    """
    Helper function to convert input text directly to decimal tuple (a, b).
    """
    converter = TextToIra(text, min_length=min_length)
    return converter.get_numbers()
