"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# Demo module - Text -> Irrational Number -> Encode -> Decode text

from Config import config
from HexSplit import HexSplit
from HexToDec import HexToDec
from SearchInRn import SearchInt, ReturnInt
from DecToHex import DecToHex
from HexJoin import HexJoin
from TextToIra import TextToIra


def text_to_hex(text: str) -> str:
    """Converts a UTF-8 string into an uppercase hexadecimal string."""
    return text.encode('utf-8').hex().upper()


def hex_to_text(hex_str: str) -> str:
    """Converts an uppercase hexadecimal string back into a UTF-8 string."""
    bytes_data = bytes.fromhex(hex_str)
    return bytes_data.decode('utf-8', errors='replace')


def encode_text_sequential(
    chunks: list[str],
    a: int,
    b: int,
    chunk_size: int | None = None,
    max_search_digits: int | None = None,
    sequential_search: bool | None = None,
) -> list[dict]:
    """
    Encodes hex chunks into irrational number sqrt(a/b).
    If sequential_search is True, ensures that each subsequent chunk search
    starts where the previous chunk ended.

    :param chunks: List of hex chunk strings.
    :param a: Numerator integer for irrational number sqrt(a/b).
    :param b: Denominator integer for irrational number sqrt(a/b).
    :param chunk_size: Character length of each hex chunk.
    :param max_search_digits: Maximum number of digits to inspect per chunk.
    :param sequential_search: Whether to advance search position sequentially.
    :return: List of encoded chunk metadata dicts (chunk_hex, decimal_value, position, length).
    """
    effective_chunk_size = (
        chunk_size if chunk_size is not None else getattr(config.search, "hex_chunk_size", 4)
    )
    effective_max_search = (
        max_search_digits
        if max_search_digits is not None
        else getattr(config.search, "max_search_digits", 10_000_000)
    )
    effective_sequential = (
        sequential_search
        if sequential_search is not None
        else getattr(config.search, "sequential_search", True)
    )

    encoded_blocks = []
    current_search_position = 1
    total_chunks = len(chunks)

    for idx, chunk in enumerate(chunks, start=1):
        dec_val = HexToDec(chunk, expected_length=effective_chunk_size)
        target_str = str(dec_val)
        search_start = current_search_position if effective_sequential else 1
        print(f"\n   [Block {idx}/{total_chunks}] Hex: '{chunk}' -> Dec: {dec_val}")
        print(f"   -> Starting search from position {search_start} in sqrt(a/b)...")

        position = SearchInt(
            a,
            b,
            target_str,
            max_search_digits=effective_max_search,
            start_position=search_start,
        )

        target_length = len(target_str)
        print(f"   -> PROGRESS: Found coordinate at position {position} (length {target_length}).")

        encoded_blocks.append({
            "chunk_hex": chunk,
            "decimal_value": dec_val,
            "position": position,
            "length": target_length,
        })

        if effective_sequential:
            current_search_position = position + target_length

    return encoded_blocks


def run_demo():
    min_len = config.text_to_ira.min_text_length
    chunk_size = config.search.hex_chunk_size
    max_search = config.search.max_search_digits
    is_seq = config.search.sequential_search

    print("==================================================")
    print(" DEMO: Text -> TextToIra -> Encode -> Decode")
    print(f" Configuration active (from inc_config.ini):")
    print(f"  * Min text length: {min_len} characters")
    print(f"  * Hex chunk size : {chunk_size} characters ({chunk_size * 4} bits)")
    print(f"  * Max search     : {max_search} digits")
    print(f"  * Sequential     : {is_seq}")
    print("==================================================")
    print("Enter 'exit' to quit the application.\n")

    while True:
        try:
            # 1. Input password for generating the irrational number
            print(f"--- [STEP 1: Enter password for irrational number generation (min. {min_len} chars)] ---")
            ira_password = input(f"Enter password for irrational number calculation (min. {min_len} chars): ").strip()

            if ira_password.lower() == 'exit':
                print("Application terminated.")
                break

            if not ira_password:
                continue

            # Convert password to irrational parameters using TextToIra
            try:
                converter = TextToIra(ira_password)
            except ValueError as ve:
                print(f" [Validation error]: {ve}\n")
                continue

            a, b = converter.get_numbers()
            print(f" -> Password split:")
            print(f"    * Part 1 (entire text) : '{converter.part1}'")
            print(f"    * Part 2 (word/chars)  : '{converter.part2}'")
            print(f" -> Generated decimal numbers from password:")
            print(f"    * Numerator 'a'   : {a}")
            print(f"    * Denominator 'b' : {b}")
            print(f"    * Irrational value: sqrt(a/b)")

            # 2. Input text to encode
            print("\n--- [STEP 2: Input text to encode] ---")
            text_to_encode = input("Enter text to encode: ").strip()

            if text_to_encode.lower() == 'exit':
                print("Application terminated.")
                break

            if not text_to_encode:
                print("Text to encode cannot be empty.\n")
                continue

            # Step 1: Convert text to Hex
            print("\n--------------------------------------------------")
            print("[Step 1/4]: Converting text to hexadecimal string...")
            hex_data = text_to_hex(text_to_encode)
            print(f" -> Original text to encode : '{text_to_encode}'")
            print(f" -> Hex representation      : {hex_data} ({len(hex_data)} hex characters)")

            # Step 2: Encoding with progress reporting
            print(f"\n[Step 2/4]: Encoding (splitting into blocks of {chunk_size} and searching in expansion)...")
            chunks = HexSplit(hex_data, chunk_size=chunk_size)
            total_chunks = len(chunks)
            print(f" -> Split into {total_chunks} block(s) of {chunk_size} hex characters ({chunk_size * 4} bits each).")

            encoded_blocks = encode_text_sequential(
                chunks,
                a,
                b,
                chunk_size=chunk_size,
                max_search_digits=max_search,
                sequential_search=is_seq,
            )

            print("\n [Encoding Summary - Final Coordinates]:")
            for idx, block in enumerate(encoded_blocks, start=1):
                print(
                    f"   * Block {idx}: Hex='{block['chunk_hex']}' | Dec={block['decimal_value']} "
                    f"-> Coordinate (Position: {block['position']}, Length: {block['length']})"
                )

            # Step 3: Decoding
            print("\n[Step 3/4]: Decoding (reconstruction from coordinates and password)...")
            decode_password = input(
                f"Enter password to decode [press Enter to use the same password]: "
            ).strip()

            if decode_password.lower() == 'exit':
                print("Application terminated.")
                break

            if not decode_password:
                decode_password = ira_password

            # Calculation of a, b for decoding from password
            try:
                decoding_converter = TextToIra(decode_password)
                dec_a, dec_b = decoding_converter.get_numbers()
            except ValueError as ve:
                print(f" [Decoding validation error]: {ve}\n")
                continue

            print(f" -> Using password for decoding: '{decode_password}'")

            decoded_chunks = []
            for idx, block in enumerate(encoded_blocks, start=1):
                pos = block["position"]
                length = block["length"]
                print(f"   [Block {idx}/{total_chunks}] Reading {length} digits from position {pos} in sqrt(a/b)...")

                retrieved_dec = ReturnInt(dec_a, dec_b, pos, length)
                retrieved_hex = DecToHex(retrieved_dec, length=chunk_size)
                print(f"   -> PROGRESS: Retrieved Dec: {retrieved_dec} -> Hex: '{retrieved_hex}'")
                decoded_chunks.append(retrieved_hex)

            decoded_hex = HexJoin(decoded_chunks)
            print(f"\n -> Joined decoded Hex: {decoded_hex}")

            # Step 4: Convert Hex back to text
            print("\n[Step 4/4]: Converting decoded Hex back to original text...")
            original_byte_len = len(text_to_encode.encode('utf-8'))
            decoded_hex_trimmed = decoded_hex[: original_byte_len * 2]
            reconstructed_text = hex_to_text(decoded_hex_trimmed)
            print(f" -> Reconstructed text: '{reconstructed_text}'")

            # Verify integrity
            if reconstructed_text == text_to_encode:
                print("\n -> [SUCCESS]: Reconstructed text fully matches the original input!\n")
            else:
                print("\n -> [WARNING]: Reconstructed text does NOT match original! (Incorrect password)\n")

        except ValueError as err:
            print(f"\n [Error]: {err}\n")
        except (KeyboardInterrupt, EOFError):
            print("\nApplication terminated.")
            break


if __name__ == "__main__":
    run_demo()
