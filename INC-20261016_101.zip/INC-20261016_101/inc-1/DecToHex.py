"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# DecToHex library module


def DecToHex(num: int, length: int = 4) -> str:
    """
    Converts a decimal integer back into an uppercase hexadecimal string padded to `length` characters.

    :param num: The decimal integer to convert.
    :param length: Number of characters for hex string (default 4).
    :return: An uppercase hexadecimal string padded with leading zeros.
    :raises TypeError: If inputs are not integers.
    :raises ValueError: If input number is out of valid range for specified hex length.
    """
    if not isinstance(num, int) or isinstance(num, bool):
        raise TypeError(f"Input must be an integer, got {type(num).__name__}")
    if not isinstance(length, int) or isinstance(length, bool):
        raise TypeError(f"length must be an integer, got {type(length).__name__}")

    max_val = (1 << (4 * length)) - 1
    if not (0 <= num <= max_val):
        raise ValueError(f"Input integer must be in range 0 to {max_val} (0x0 to 0x{'F'*length}), got {num}")

    return f"{num:0{length}X}"


# Alias for snake_case python convention
dec_to_hex = DecToHex


