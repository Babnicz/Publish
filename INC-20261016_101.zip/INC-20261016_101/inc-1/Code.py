"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# Code library module

from Config import config
from HexSplit import HexSplit
from HexToDec import HexToDec
from SearchInRn import SearchInt


def CodeHex(
    hex_str: str,
    a: int,
    b: int,
    chunk_size: int | None = None,
    max_search_digits: int | None = None,
    sequential_search: bool | None = None,
) -> list[dict]:
    """
    Encodes a hexadecimal string by splitting it into chunks, converting each chunk to decimal,
    and searching for its position in the fractional expansion of sqrt(a/b).

    :param hex_str: Hexadecimal string to encode.
    :param a: Numerator integer for irrational number sqrt(a/b).
    :param b: Denominator integer for irrational number sqrt(a/b).
    :param chunk_size: Size of hex chunks (defaults to config value if None, fallback 4).
    :param max_search_digits: Maximum digits to search in irrational number expansion (defaults to config value).
    :param sequential_search: If True, searches each subsequent chunk starting where the previous
                             sequence ended, preventing identical positions (defaults to config value).
    :return: A list of dictionaries, each containing encoding metadata for a chunk:
             {"chunk_hex": str, "decimal_value": int, "position": int, "length": int}
    """
    effective_chunk_size = (
        chunk_size if chunk_size is not None else getattr(config.search, "hex_chunk_size", 4)
    )
    effective_max_search = (
        max_search_digits
        if max_search_digits is not None
        else getattr(config.search, "max_search_digits", 1_000_000)
    )
    effective_sequential = (
        sequential_search
        if sequential_search is not None
        else getattr(config.search, "sequential_search", False)
    )

    chunks = HexSplit(hex_str, chunk_size=effective_chunk_size)
    encoded_blocks = []
    current_search_position = 1

    for chunk in chunks:
        dec_val = HexToDec(chunk, expected_length=effective_chunk_size)
        target_str = str(dec_val)
        position = SearchInt(
            a,
            b,
            target_str,
            max_search_digits=effective_max_search,
            start_position=current_search_position if effective_sequential else 1,
        )

        encoded_blocks.append({
            "chunk_hex": chunk,
            "decimal_value": dec_val,
            "position": position,
            "length": len(target_str)
        })

        if effective_sequential:
            current_search_position = position + len(target_str)

    return encoded_blocks


# Aliases
code_hex = CodeHex
Code = CodeHex
code = CodeHex


