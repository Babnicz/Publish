"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# INumbers library module

import decimal


def CreateINumber(a: int, b: int, precision_digits: int = 38) -> int:
    """
    Calculates an irrational number from two integers 'a' and 'b',
    extracts the digits after the decimal point, and returns them as a 128-bit integer.

    Validates that the combination of inputs forms a valid real (and irrational) number.

    :param a: First integer input (numerator).
    :param b: Second integer input (denominator).
    :param precision_digits: Number of digits to extract after decimal point (default 38, fitting in 128-bit int).
    :return: A 128-bit integer formed by the digits behind the decimal point.
    :raises TypeError: If inputs are not integers.
    :raises ValueError: If input combination does not produce a real number or produces a rational number.
    """
    if not isinstance(a, int) or isinstance(a, bool):
        raise TypeError(f"Input 'a' must be an integer, got {type(a).__name__} instead.")
    if not isinstance(b, int) or isinstance(b, bool):
        raise TypeError(f"Input 'b' must be an integer, got {type(b).__name__} instead.")

    if b == 0:
        raise ValueError("Combination does not produce a real number: division by zero (b = 0).")

    # Check if ratio a/b is negative (square root would be imaginary / complex number)
    if (a > 0 and b < 0) or (a < 0 and b > 0):
        raise ValueError(
            f"Combination of a={a} and b={b} does not produce a real number (square root of a negative value)."
        )

    ctx = decimal.getcontext()
    original_prec = ctx.prec
    try:
        ctx.prec = max(100, precision_digits + 20)

        a_dec = decimal.Decimal(a)
        b_dec = decimal.Decimal(b)
        ratio = a_dec / b_dec

        irrational_val = ratio.sqrt()

        val_str = str(irrational_val)
        if "." in val_str:
            frac_str = val_str.split(".")[1]
        else:
            frac_str = ""

        # Check if fractional part exists and is not all zeros (rational number check)
        if not frac_str or set(frac_str) == {"0"}:
            raise ValueError(f"Combination of a={a} and b={b} yields a rational number, not an irrational number.")

        extracted_digits = frac_str[:precision_digits]
        result_int = int(extracted_digits)

        if result_int >= (1 << 128):
            raise ValueError(f"Resulting integer exceeds 128-bit limit.")

        return result_int

    finally:
        ctx.prec = original_prec


# Aliases for pythonic naming conventions
create_i_number = CreateINumber
create_inumber = CreateINumber

from SearchInRn import SearchInt, ReturnInt, search_int, return_int


