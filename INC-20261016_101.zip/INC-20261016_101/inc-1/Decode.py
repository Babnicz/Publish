"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# Decode library module

from Config import config
from DecToHex import DecToHex
from HexJoin import HexJoin
from SearchInRn import ReturnInt


def DecodeHex(encoded_blocks: list[dict], a: int, b: int, chunk_length: int | None = None) -> str:
    """
    Decodes a list of encoded block metadata back into the original hexadecimal string.

    :param encoded_blocks: List of dictionaries with 'position' and 'length' keys.
    :param a: Numerator integer for irrational number sqrt(a/b).
    :param b: Denominator integer for irrational number sqrt(a/b).
    :param chunk_length: Expected character length of decoded hex chunks (defaults to config value if None, fallback 4).
    :return: Reconstructed uppercase hexadecimal string.
    :raises TypeError: If inputs are invalid.
    :raises ValueError: If block structure is missing required keys.
    """
    if not isinstance(encoded_blocks, list):
        raise TypeError(f"encoded_blocks must be a list, got {type(encoded_blocks).__name__}")

    effective_chunk_length = (
        chunk_length if chunk_length is not None else getattr(config.search, "hex_chunk_size", 4)
    )

    decoded_chunks = []

    for idx, block in enumerate(encoded_blocks):
        if not isinstance(block, dict):
            raise TypeError(f"Block at index {idx} must be a dictionary, got {type(block).__name__}")
        if "position" not in block or "length" not in block:
            raise ValueError(f"Block at index {idx} must contain 'position' and 'length' keys.")

        position = block["position"]
        length = block["length"]

        dec_val = ReturnInt(a, b, position, length)
        hex_chunk = DecToHex(dec_val, length=effective_chunk_length)
        decoded_chunks.append(hex_chunk)

    return HexJoin(decoded_chunks)


# Aliases
decode_hex = DecodeHex
Decode = DecodeHex
decode = DecodeHex


