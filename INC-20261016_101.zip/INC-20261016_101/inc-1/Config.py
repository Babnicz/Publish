"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# Config module for INC library

import configparser
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SearchConfig:
    hex_chunk_size: int = 4
    max_search_digits: int = 10_000_000
    sequential_search: bool = True


@dataclass
class TextToIraConfig:
    min_text_length: int = 20
    single_word_fallback_length: int = 10


@dataclass
class INumbersConfig:
    precision_digits: int = 38


@dataclass
class AppConfig:
    search: SearchConfig
    text_to_ira: TextToIraConfig
    inumbers: INumbersConfig


_DEFAULT_CONFIG_FILENAME = "inc_config.ini"


def get_default_config_path() -> Path:
    """Returns the default path to the configuration file in the project folder."""
    return Path(__file__).resolve().parent / _DEFAULT_CONFIG_FILENAME


def load_config(config_path: str | Path | None = None) -> AppConfig:
    """
    Loads application configuration from an INI file.
    If the file does not exist, defaults are used.
    """
    path = Path(config_path) if config_path else get_default_config_path()

    search_cfg = SearchConfig()
    text_cfg = TextToIraConfig()
    inumbers_cfg = INumbersConfig()

    if path.is_file():
        parser = configparser.ConfigParser()
        try:
            parser.read(str(path), encoding="utf-8")

            if parser.has_section("search"):
                s = parser["search"]
                search_cfg.hex_chunk_size = s.getint("hex_chunk_size", fallback=search_cfg.hex_chunk_size)
                search_cfg.max_search_digits = s.getint("max_search_digits", fallback=search_cfg.max_search_digits)
                search_cfg.sequential_search = s.getboolean("sequential_search", fallback=search_cfg.sequential_search)

            if parser.has_section("text_to_ira"):
                t = parser["text_to_ira"]
                text_cfg.min_text_length = t.getint("min_text_length", fallback=text_cfg.min_text_length)
                text_cfg.single_word_fallback_length = t.getint(
                    "single_word_fallback_length", fallback=text_cfg.single_word_fallback_length
                )

            if parser.has_section("inumbers"):
                num = parser["inumbers"]
                inumbers_cfg.precision_digits = num.getint("precision_digits", fallback=inumbers_cfg.precision_digits)

        except Exception as err:
            # Fallback to defaults on corrupt config
            print(f"[Warning] Failed to parse configuration file '{path}': {err}. Using defaults.")

    return AppConfig(
        search=search_cfg,
        text_to_ira=text_cfg,
        inumbers=inumbers_cfg,
    )


# Singleton instance for convenient global access
config: AppConfig = load_config()


def reload_config(config_path: str | Path | None = None) -> AppConfig:
    """Reloads global configuration from file."""
    global config
    config = load_config(config_path)
    return config
