"""
===============================================================================
Copyright (c) 2025. All Rights Reserved.

This software is released under a dual licensing model:
1. GNU General Public License v3.0 (GPLv3) for open-source / non-commercial use.
2. Commercial License for proprietary and closed-source use.

For details, terms, and conditions, see the LICENSE file in the root directory.
===============================================================================
"""

# HexToDec library module


def HexToDec(hex_str: str, expected_length: int = 4) -> int:
    """
    Converts a hexadecimal string into a decimal integer.

    :param hex_str: A hexadecimal string representing data.
    :param expected_length: Expected character length (default 4). Set to None to skip length validation.
    :return: The converted integer value.
    :raises TypeError: If input is not a string.
    :raises ValueError: If input is not a valid hexadecimal string of expected length.
    """
    if not isinstance(hex_str, str):
        raise TypeError(f"Input must be a string, got {type(hex_str).__name__}")

    hex_str = hex_str.strip()
    if expected_length is not None and len(hex_str) != expected_length:
        raise ValueError(f"Input string must be exactly {expected_length} characters long, got length {len(hex_str)}")

    try:
        return int(hex_str, 16)
    except ValueError as e:
        raise ValueError(f"Invalid hexadecimal string '{hex_str}'") from e


# Alias for snake_case python convention
hex_to_dec = HexToDec


